STUDENT INFORMATION:

Name: Phạm Hoàng Phương

Student ID: ITCSIU23056

Class: ITCS23IU41

COMPLETED EXERCISES:
- [x] Exercise 5: Search Functionality
- [x] Exercise 6: Validation Enhancement
- [x] Exercise 7: Pagination
- [ ] Bonus 1: CSV Export
- [x] Bonus 2: Sortable Columns
- [x] Bonus 3: Bulk Delete

TIME SPENT: 4 hours

